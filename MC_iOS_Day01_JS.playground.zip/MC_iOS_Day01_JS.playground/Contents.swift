import UIKit

var str = "JayaShankar"
var str2 = "Mangina"
var name = str2+" "+str
print("Name:\(name)")


var a = 10
var b = 20
print("Age:\(a+b)")


